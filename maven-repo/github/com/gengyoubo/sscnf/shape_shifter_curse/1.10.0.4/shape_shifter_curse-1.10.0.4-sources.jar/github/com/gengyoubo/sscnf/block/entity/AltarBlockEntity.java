package github.com.gengyoubo.sscnf.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import github.com.gengyoubo.sscnf.other.menu.AltarMenu;
import github.com.gengyoubo.sscnf.recipe.altar.AltarRecipe;
import github.com.gengyoubo.sscnf.registry.ModBlockEntities;
import github.com.gengyoubo.sscnf.registry.ModRecipeSerializers;

import java.util.*;

public class AltarBlockEntity extends BlockEntity implements WorldlyContainer, MenuProvider {
    public static final int MAX_FUEL = 102400;
    private static Map<net.minecraft.world.item.Item, Integer> fuelMap = null;
    private static Map<net.minecraft.world.item.Item, Integer> getFuelMap() {
        if (fuelMap == null) {
            fuelMap = new HashMap<>();
            try {
                var item = github.com.gengyoubo.sscnf.registry.ModItems.UNTREATED_MOONDUST.get();
                fuelMap.put(item, 800);
            } catch (Exception ignored) {}
            try {
                var reg = net.minecraft.core.registries.BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(github.com.gengyoubo.sscnf.ShapeShifterCurseNeoForge.RESOURCE_NAMESPACE, "untreated_moondust"));
                if (reg != null) fuelMap.putIfAbsent(reg, 800);
            } catch (Exception ignored) {}
        }
        return fuelMap;
    }
    public static boolean canFuel(ItemStack s) { return getFuelMap().containsKey(s.getItem()); }
    public static int getFuelTime(ItemStack s) { return getFuelMap().getOrDefault(s.getItem(), 0); }

    private NonNullList<ItemStack> items = NonNullList.withSize(12, ItemStack.EMPTY);
    public UUID lastUser;
    private AltarRecipe currentRecipe;
    public int progress;
    public int totalProgress;
    public int fuelTime;
    private boolean needCheckRecipe = true;

    public final ContainerData dataAccess = new ContainerData() {
        @Override public int get(int i) {
            return switch (i) {
                case 0 -> progress;
                case 1 -> totalProgress;
                case 2 -> fuelTime & 0xffff;
                case 3 -> fuelTime >>> 16;
                default -> 0;
            };
        }
        @Override public void set(int i, int v) {
            switch (i) {
                case 0 -> progress = v;
                case 1 -> totalProgress = v;
                case 2 -> fuelTime = (fuelTime & 0xffff0000) | (v & 0xffff);
                case 3 -> fuelTime = (fuelTime & 0xffff) | ((v & 0xffff) << 16);
            }
        }
        @Override public int getCount() { return 4; }
    };

    public AltarBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ALTAR.get(), pos, state);
    }

    @Override public Component getDisplayName() { return Component.translatable("block.shape-shifter-curse.altar"); }
    @Override public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) { return new AltarMenu(id, inv, this, dataAccess); }

    // Container
    @Override public int getContainerSize() { return items.size(); }
    @Override public boolean isEmpty() { for (var s : items) if (!s.isEmpty()) return false; return true; }
    @Override public ItemStack getItem(int i) { return items.get(i); }
    @Override public ItemStack removeItem(int slot, int count) { var s = ContainerHelper.removeItem(items, slot, count); if (!s.isEmpty()) { needCheckRecipe = true; setChanged(); } return s; }
    @Override public ItemStack removeItemNoUpdate(int slot) { var s = ContainerHelper.takeItem(items, slot); needCheckRecipe = true; return s; }
    @Override public void setItem(int slot, ItemStack stack) { items.set(slot, stack); if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize()); needCheckRecipe = true; setChanged(); }
    @Override public boolean stillValid(Player p) { if (level == null || level.getBlockEntity(worldPosition) != this) return false; return p.distanceToSqr(worldPosition.getX()+0.5, worldPosition.getY()+0.5, worldPosition.getZ()+0.5) <= 64; }
    @Override public void clearContent() { items.clear(); needCheckRecipe = true; }
    @Override public int getMaxStackSize() {
        return WorldlyContainer.super.getMaxStackSize();
    }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot < 9) return true;
        if (slot == 9) return true;
        if (slot == 10) return canFuel(stack);
        return false;
    }
    @Override public int[] getSlotsForFace(net.minecraft.core.Direction dir) {
        if (dir == net.minecraft.core.Direction.UP) return new int[]{0,1,2,3,4,5,6,7,8};
        if (dir == net.minecraft.core.Direction.DOWN) return new int[]{11};
        return new int[]{10,9};
    }
    @Override public boolean canPlaceItemThroughFace(int slot, ItemStack stack, net.minecraft.core.Direction dir) { return canPlaceItem(slot, stack); }
    @Override public boolean canTakeItemThroughFace(int slot, ItemStack stack, net.minecraft.core.Direction dir) { return slot == 11; }

    @Override public void loadAdditional(CompoundTag tag, net.minecraft.core.HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items, registries);
        if (tag.getInt("InventoryVersion") < 2) { items.set(11, items.get(10)); items.set(10, ItemStack.EMPTY); }
        if (tag.hasUUID("LastUser")) lastUser = tag.getUUID("LastUser");
        fuelTime = tag.getInt("FuelTime");
        progress = tag.getInt("Progress");
        totalProgress = tag.getInt("TotalProgress");
    }
    @Override protected void saveAdditional(CompoundTag tag, net.minecraft.core.HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, items, registries);
        tag.putInt("InventoryVersion", 2);
        if (lastUser != null) tag.putUUID("LastUser", lastUser);
        tag.putInt("FuelTime", fuelTime);
        tag.putInt("Progress", progress);
        tag.putInt("TotalProgress", totalProgress);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, AltarBlockEntity be) {
        if (level.isClientSide) return;
        if (be.needCheckRecipe) { be.checkRecipe(); be.needCheckRecipe = false; }
        boolean dirty = false;
        ItemStack fuel = be.items.get(10);
        int fuelValue = getFuelTime(fuel);
        if (fuelValue > 0 && be.fuelTime <= MAX_FUEL - fuelValue) {
            be.fuelTime += fuelValue;
            fuel.shrink(1);
            dirty = true;
        }
        if (be.currentRecipe != null) {
            int usage = be.currentRecipe.fuelUsage(be.progress);
            if (be.fuelTime >= usage) {
                be.fuelTime -= usage;
                be.progress++;
                dirty = true;
            }
            if (be.progress >= be.currentRecipe.getRecipeTime()) {
                if (be.craftRecipe()) {
                    be.progress = 0;
                } else {
                    be.progress = 0;
                }
            }
        } else if (be.progress > 0) {
            be.progress = 0; dirty = true;
        }
        if (dirty) { be.checkRecipe(); be.setChanged(); }
    }

    private void checkRecipe() {
        if (level == null) return;
        if (currentRecipe != null) {
            if (currentRecipe.matches(new github.com.gengyoubo.sscnf.recipe.altar.AltarInput(this), level) && currentRecipe.canCraft(getLastPlayer())) {
                if (canOutput(currentRecipe)) return;
            }
            currentRecipe = null; totalProgress = 0;
        }
        AltarRecipe match = findMatch(ModRecipeSerializers.ALTAR_SHAPELESS_TYPE.get());
        if (match == null) match = findMatch(ModRecipeSerializers.ALTAR_SHAPED_TYPE.get());
        if (match == null) {
            currentRecipe = null; totalProgress = 0; progress = 0;
            return;
        }
        currentRecipe = match;
        totalProgress = match.getRecipeTime();
        progress = 0;
    }

    @SuppressWarnings("unchecked")
    private AltarRecipe findMatch(net.minecraft.world.item.crafting.RecipeType<?> type) {
        net.minecraft.world.item.crafting.RecipeType<AltarRecipe> altarType =
                (net.minecraft.world.item.crafting.RecipeType<AltarRecipe>) type;
        var opt = Objects.requireNonNull(level).getRecipeManager().getRecipeFor(altarType, new github.com.gengyoubo.sscnf.recipe.altar.AltarInput(this), level);
        if (opt.isEmpty()) return null;
        AltarRecipe candidate = opt.get().value();
        if (!candidate.canCraft(getLastPlayer())) return null;
        if (!canOutput(candidate)) return null;
        return candidate;
    }

    private Player getLastPlayer() {
        if (level == null || lastUser == null) return null;
        return level.getPlayerByUUID(lastUser);
    }

    private boolean canOutput(AltarRecipe r) {
        ItemStack outSlot = items.get(11);
        ItemStack result = r.assemble(new github.com.gengyoubo.sscnf.recipe.altar.AltarInput(this), Objects.requireNonNull(level).registryAccess());
        if (result.isEmpty()) return false;
        if (outSlot.isEmpty()) return true;
        if (!ItemStack.isSameItemSameComponents(result, outSlot)) return false;
        return outSlot.getCount() + result.getCount() <= outSlot.getMaxStackSize() && outSlot.getCount() + result.getCount() <= getMaxStackSize();
    }

    private boolean craftRecipe() {
        if (currentRecipe == null || level == null) return false;
        if (!canOutput(currentRecipe)) return false;
        ItemStack result = currentRecipe.assemble(new github.com.gengyoubo.sscnf.recipe.altar.AltarInput(this), level.registryAccess());
        ItemStack outSlot = items.get(11);
        if (outSlot.isEmpty()) items.set(11, result.copy());
        else outSlot.grow(result.getCount());
        if (currentRecipe instanceof github.com.gengyoubo.sscnf.recipe.altar.AltarShapedRecipe shaped) {
            for (int y = 0; y < 3; y++) {
                for (int x = 0; x < 3; x++) {
                    if (shaped.ingredientAt(x, y).isEmpty()) continue;
                    consumeInput(x + y * 3);
                }
            }
        } else if (currentRecipe instanceof github.com.gengyoubo.sscnf.recipe.altar.AltarShapelessRecipe) {
            for (int i = 0; i < 9; i++) consumeInput(i);
        } else {
            // Unknown AltarRecipe implementation: consume one item from each occupied input slot.
            for (int i = 0; i < 9; i++) {
                ItemStack s = items.get(i);
                if (!s.isEmpty()) s.shrink(1);
            }
        }
        return true;
    }

    private void consumeInput(int slot) {
        ItemStack input = items.get(slot);
        if (input.isEmpty()) return;
        ItemStack remainder = input.is(net.minecraft.world.item.Items.POWDER_SNOW_BUCKET)
                ? new ItemStack(net.minecraft.world.item.Items.BUCKET) : input.getCraftingRemainingItem();
        input.shrink(1);
        if (!remainder.isEmpty()) {
            if (input.isEmpty()) items.set(slot, remainder);
            else if (level != null) net.minecraft.world.Containers.dropItemStack(level,
                    worldPosition.getX() + 0.5, worldPosition.getY() + 1, worldPosition.getZ() + 0.5, remainder);
        }
    }
}
