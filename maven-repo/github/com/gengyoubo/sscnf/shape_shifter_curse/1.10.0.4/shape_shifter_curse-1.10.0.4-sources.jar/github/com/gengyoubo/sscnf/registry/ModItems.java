package github.com.gengyoubo.sscnf.registry;

import net.minecraft.ChatFormatting;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;
import github.com.gengyoubo.sscnf.ShapeShifterCurseNeoForge;
import github.com.gengyoubo.sscnf.items.BookOfShapeShifterItem;
import github.com.gengyoubo.sscnf.items.SelectFormItem;
import github.com.gengyoubo.sscnf.items.TooltipItem;
import github.com.gengyoubo.sscnf.items.FormGrowthItem;
import github.com.gengyoubo.sscnf.items.accessory.*;
import github.com.gengyoubo.sscnf.items.armors.MorphScaleArmor;
import github.com.gengyoubo.sscnf.items.armors.NetheriteMorphScaleArmor;
import github.com.gengyoubo.sscnf.items.tools.AuxiliaryAxe;
import github.com.gengyoubo.sscnf.items.tools.AuxiliaryPickaxe;
import github.com.gengyoubo.sscnf.items.tools.AuxiliarySword;
import github.com.gengyoubo.sscnf.items.tools.BottledSnowfall;
import github.com.gengyoubo.sscnf.items.tools.DiamondMiningClaw;
import github.com.gengyoubo.sscnf.items.tools.SuperMorphScaleCore;
import github.com.gengyoubo.sscnf.form.FormGrowthService;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(
            BuiltInRegistries.ITEM,
            ShapeShifterCurseNeoForge.RESOURCE_NAMESPACE
    );

    public static final DeferredHolder<Item, ? extends Item> GRAPHENE_BLADE = ITEMS.register("graphene_blade",
            () -> new net.minecraft.world.item.SwordItem(net.minecraft.world.item.Tiers.DIAMOND,
                    new Item.Properties().durability(128).attributes(net.minecraft.world.item.SwordItem.createAttributes(net.minecraft.world.item.Tiers.DIAMOND, 4, -2.4F))));
    public static final DeferredHolder<Item, ? extends Item> COMPOUND_KINETIC_BOW = ITEMS.register("compound_kinetic_bow",
            () -> new net.minecraft.world.item.BowItem(new Item.Properties().durability(768)));
    public static final DeferredHolder<Item, ? extends Item> HEALING_CHARM = ITEMS.register("healing_charm_paper", () -> new github.com.gengyoubo.sscnf.items.PotionCharmItem(net.minecraft.world.item.alchemy.Potions.STRONG_HEALING));
    public static final DeferredHolder<Item, ? extends Item> HARMING_CHARM = ITEMS.register("harming_charm_paper", () -> new github.com.gengyoubo.sscnf.items.PotionCharmItem(net.minecraft.world.item.alchemy.Potions.STRONG_HARMING));
    public static final DeferredHolder<Item, ? extends Item> POISON_CHARM = ITEMS.register("poison_charm_paper", () -> new github.com.gengyoubo.sscnf.items.PotionCharmItem(net.minecraft.world.item.alchemy.Potions.STRONG_POISON));
    public static final java.util.List<DeferredHolder<Item, ? extends Item>> BETA_ITEMS = registerBetaItems();
    private static java.util.List<DeferredHolder<Item, ? extends Item>> registerBetaItems() {
        var items = new java.util.ArrayList<DeferredHolder<Item, ? extends Item>>();
        for (String name : new String[]{"amulet_bracelet_plus", "attach_hook_plus", "charm_of_hollow_fang_plus",
                "charm_of_night_crystal_plus", "charm_of_reverse_thermometer_plus", "collar_of_whiskers_plus",
                "digestion_fiber_ball_plus", "fountain_belt_plus", "frost_pawglove_plus", "venom_spindle_plus", "withered_bandage_plus"}) {
            items.add(ITEMS.register(name, () -> new github.com.gengyoubo.sscnf.items.accessory.FormTrinket(new Item.Properties().rarity(net.minecraft.world.item.Rarity.RARE))));
        }
        for (String name : new String[]{"dune_catalyst_core", "foxfire_catalyst_core", "frost_catalyst_core", "jungle_catalyst_core", "night_catalyst_core", "surge_catalyst_core", "web_catalyst_core"}) {
            items.add(ITEMS.register(name, () -> new TooltipItem(new Item.Properties(), "item.shape-shifter-curse." + name + ".tooltip", ChatFormatting.YELLOW)));
        }
        items.add(ITEMS.register("bottled_snowfall_plus", () -> new BottledSnowfall(
                github.com.gengyoubo.sscnf.items.tools.BottledSnowfallToolMaterial.INSTANCE, 1, 1.0F,
                new Item.Properties().stacksTo(1).rarity(net.minecraft.world.item.Rarity.RARE))));
        for (String name : new String[]{"glint_prism", "explosive_charm_paper"})
            items.add(ITEMS.register(name, () -> new Item(new Item.Properties())));
        return java.util.List.copyOf(items);
    }

    public static final DeferredHolder<Item, ? extends Item> BOOK_OF_SHAPE_SHIFTER = ITEMS.register(
            "book_of_shape_shifter",
            () -> new BookOfShapeShifterItem(new Item.Properties())
    );

    public static final DeferredHolder<Item, ? extends Item> SELECT_FORM_ITEM = ITEMS.register(
            "select_form_item",
            () -> new SelectFormItem(new Item.Properties())
    );

    // Curios trinkets (accessory slots)
    public static final DeferredHolder<Item, ? extends Item> AMULET_BRACELET = ITEMS.register(
            "amulet_bracelet", () -> new AmuletBraceletAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> ATTACH_HOOK = ITEMS.register(
            "attach_hook", () -> new AttachHookAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> CHARM_OF_HOLLOW_FANG = ITEMS.register(
            "charm_of_hollow_fang", () -> new CharmOfHollowFangAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> CHARM_OF_NIGHT_CRYSTAL = ITEMS.register(
            "charm_of_night_crystal", () -> new CharmOfNightCrystalAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> CHARM_OF_REVERSE_THERMOMETER = ITEMS.register(
            "charm_of_reverse_thermometer", () -> new CharmOfReverseThermometerAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> COLLAR_OF_TENSION = ITEMS.register(
            "collar_of_tension", () -> new CollarOfTensionAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> COLLAR_OF_WHISKERS = ITEMS.register(
            "collar_of_whiskers", () -> new CollarOfWhiskersAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> DIGESTION_FIBER_BALL = ITEMS.register(
            "digestion_fiber_ball", () -> new DigestionFiberBallAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> FOUNTAIN_BELT = ITEMS.register(
            "fountain_belt", () -> new FountainBeltAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> FROST_PAWGLOVE = ITEMS.register(
            "frost_pawglove", () -> new FrostPawgloveAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> RESONANT_CORE = ITEMS.register(
            "resonant_core", () -> new ResonantCoreAccessory(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> VENOM_SPINDLE = ITEMS.register(
            "venom_spindle", () -> new VenomSpindle(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> WITHERED_BANDAGE = ITEMS.register(
            "withered_bandage", () -> new WitheredBandageAccessory(new Item.Properties().stacksTo(1)));

    public static final DeferredHolder<Item, ? extends Item> UNTREATED_MOONDUST = ITEMS.register(
            "untreated_moondust", () -> new TooltipItem(
                    new Item.Properties(),
                    "item.shape-shifter-curse.untreated_moondust.tooltip",
                    ChatFormatting.GRAY));

    public static final DeferredHolder<Item, ? extends Item> MOONDUST_MATRIX = ITEMS.register(
            "moondust_matrix", () -> new TooltipItem(
                    new Item.Properties().stacksTo(64),
                    "item.shape-shifter-curse.moondust_matrix.tooltip",
                    ChatFormatting.GRAY));

    public static final DeferredHolder<Item, ? extends Item> MOONDUST_CRYSTAL_SHARD = ITEMS.register(
            "moondust_crystal_shard", () -> new TooltipItem(
                    new Item.Properties().stacksTo(64),
                    "item.shape-shifter-curse.moondust_crystal_shard.tooltip",
                    ChatFormatting.YELLOW));

    public static final DeferredHolder<Item, ? extends Item> ECTOPLASM_RAG = ITEMS.register(
            "ectoplasm_rag", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> FIRE_CHARM_PAPER = ITEMS.register(
            "fire_charm_paper", () -> new TooltipItem(
                    new Item.Properties().stacksTo(64),
                    "item.shape-shifter-curse.fire_charm_paper.tooltip",
                    ChatFormatting.YELLOW));

    public static final DeferredHolder<Item, ? extends Item> ICON_CURSED_MOON = ITEMS.register(
            "icon_cursed_moon", () -> new Item(new Item.Properties().stacksTo(1)));

    public static final DeferredHolder<Item, ? extends Item> WEB_PROJECTILE = ITEMS.register(
            "web_projectile", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> SILK_DEW = ITEMS.register(
            "silk_dew", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> CATALYST = ITEMS.register(
            "catalyst", () -> new FormGrowthItem(new Item.Properties(), FormGrowthService.Mode.CATALYST));

    public static final DeferredHolder<Item, ? extends Item> POWERFUL_CATALYST = ITEMS.register(
            "powerful_catalyst", () -> new FormGrowthItem(new Item.Properties(), FormGrowthService.Mode.POWERFUL_CATALYST));

    public static final DeferredHolder<Item, ? extends Item> INHIBITOR = ITEMS.register(
            "inhibitor", () -> new FormGrowthItem(new Item.Properties(), FormGrowthService.Mode.INHIBITOR));

    public static final DeferredHolder<Item, ? extends Item> POWERFUL_INHIBITOR = ITEMS.register(
            "powerful_inhibitor", () -> new FormGrowthItem(new Item.Properties(), FormGrowthService.Mode.POWERFUL_INHIBITOR));

    public static final DeferredHolder<Item, ? extends Item> MOONDUST_CRYSTAL_GRIT_ITEM = ITEMS.register(
            "moondust_crystal_grit", () -> new BlockItem(
                    ModBlocks.MOONDUST_CRYSTAL_GRIT.get(), new Item.Properties()));

    // --- 1.10.0 fabric parity: block items + ripple_mirror ---
    public static final DeferredHolder<Item, ? extends Item> DEW_COVERED_COBWEB_ITEM = ITEMS.register(
            "dew_covered_cobweb", () -> new BlockItem(ModBlocks.DEW_COVERED_COBWEB.get(), new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> WEB_COMPOSTER_ITEM = ITEMS.register(
            "web_composter", () -> new BlockItem(ModBlocks.WEB_COMPOSTER.get(), new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> ALTAR_ITEM = ITEMS.register(
            "altar", () -> new BlockItem(ModBlocks.ALTAR.get(), new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> FORM_ATTUNER_ITEM = ITEMS.register(
            "form_attuner", () -> new BlockItem(ModBlocks.FORM_ATTUNER.get(), new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> RIPPLE_MIRROR = ITEMS.register(
            "ripple_mirror", () -> new github.com.gengyoubo.sscnf.items.RippleMirror(
                    new Item.Properties()));

    public static final DeferredHolder<Item, ? extends Item> TEMP_WEB_BRIDGE_ITEM = ITEMS.register(
            "temp_web_bridge", () -> new BlockItem(ModBlocks.TEMP_WEB_BRIDGE.get(), new Item.Properties()));

    // --- 1.10.0 fabric parity: tools / armor / special items referenced by recipes & models ---
    public static final DeferredHolder<Item, ? extends Item> AUXILIARY_AXE = ITEMS.register(
            "auxiliary_axe", () -> new AuxiliaryAxe(
                    github.com.gengyoubo.sscnf.items.tools.AuxiliaryAxeToolMaterial.INSTANCE,
                    1.0F, -2.4F, new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> AUXILIARY_PICKAXE = ITEMS.register(
            "auxiliary_pickaxe", () -> new AuxiliaryPickaxe(
                    github.com.gengyoubo.sscnf.items.tools.AuxiliaryPickaxeToolMaterial.INSTANCE,
                    1, -2.8F, new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> AUXILIARY_SWORD = ITEMS.register(
            "auxiliary_sword", () -> new AuxiliarySword(
                    github.com.gengyoubo.sscnf.items.tools.AuxiliarySwordToolMaterial.INSTANCE,
                    1, -2.4F, new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> BOTTLED_SNOWFALL = ITEMS.register(
            "bottled_snowfall", () -> new BottledSnowfall(
                    github.com.gengyoubo.sscnf.items.tools.BottledSnowfallToolMaterial.INSTANCE,
                    1, 1.0F, new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> DIAMOND_MINING_CLAW = ITEMS.register(
            "diamond_mining_claw", () -> new DiamondMiningClaw(
                    github.com.gengyoubo.sscnf.items.tools.DiamondMiningClawToolMaterial.INSTANCE,
                    1, -2.4F, new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> MORPHSCALE_CORE = ITEMS.register(
            "morphscale_core", () -> new TooltipItem(new Item.Properties(), "item.shape-shifter-curse.morphscale_core.tooltip", ChatFormatting.GRAY));
    public static final DeferredHolder<Item, ? extends Item> SUPER_MORPHSCALE_CORE = ITEMS.register(
            "super_morphscale_core", () -> new SuperMorphScaleCore(new Item.Properties().stacksTo(1).durability(512)));
    public static final DeferredHolder<Item, ? extends Item> MORPHSCALE_HEADRING = ITEMS.register(
            "morphscale_headring", () -> new MorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.HELMET, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> MORPHSCALE_VEST = ITEMS.register(
            "morphscale_vest", () -> new MorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> MORPHSCALE_CUISH = ITEMS.register(
            "morphscale_cuish", () -> new MorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> MORPHSCALE_ANKLET = ITEMS.register(
            "morphscale_anklet", () -> new MorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> NETHERITE_MORPHSCALE_HEADRING = ITEMS.register(
            "netherite_morphscale_headring", () -> new NetheriteMorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.HELMET, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> NETHERITE_MORPHSCALE_VEST = ITEMS.register(
            "netherite_morphscale_vest", () -> new NetheriteMorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> NETHERITE_MORPHSCALE_CUISH = ITEMS.register(
            "netherite_morphscale_cuish", () -> new NetheriteMorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> NETHERITE_MORPHSCALE_ANKLET = ITEMS.register(
            "netherite_morphscale_anklet", () -> new NetheriteMorphScaleArmor(net.minecraft.world.item.ArmorItem.Type.BOOTS, new Item.Properties()));
    // cosmetics / spawn eggs / misc models present in fabric jar
    public static final DeferredHolder<Item, ? extends Item> CREATIVE_INHIBITOR = ITEMS.register(
            "creative_inhibitor", () -> new github.com.gengyoubo.sscnf.items.CreativeInhibitor(new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> CURSED_BOOK_OF_SHAPE_SHIFTER = ITEMS.register(
            "cursed_book_of_shape_shifter", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_TRINKET = ITEMS.register(
            "custom_trinket", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredHolder<Item, ? extends Item> PATRON_FORM_ITEM = ITEMS.register(
            "patron_form_item", () -> new github.com.gengyoubo.sscnf.items.PatronFormItem(new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> SPIDER_FLUID_COCOON = ITEMS.register(
            "spider_fluid_cocoon", () -> new github.com.gengyoubo.sscnf.items.SpiderFluidCocoon(new Item.Properties()));
    // Transformative spawn eggs create the dedicated entities, which apply the
    // matching temporary transformation effect on a successful attack.
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_AXOLOTL_SPAWN_EGG = ITEMS.register(
            "custom_axolotl_spawn_egg", () -> new net.neoforged.neoforge.common.DeferredSpawnEggItem(ModEntities.TRANSFORMATIVE_AXOLOTL, 9145227, 14985134, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_BAT_SPAWN_EGG = ITEMS.register(
            "custom_bat_spawn_egg", () -> new net.neoforged.neoforge.common.DeferredSpawnEggItem(ModEntities.TRANSFORMATIVE_BAT, 9145227, 2039583, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_OCELOT_SPAWN_EGG = ITEMS.register(
            "custom_ocelot_spawn_egg", () -> new net.neoforged.neoforge.common.DeferredSpawnEggItem(ModEntities.TRANSFORMATIVE_OCELOT, 9145227, 16547869, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_SPIDER_SPAWN_EGG = ITEMS.register(
            "custom_spider_spawn_egg", () -> new net.neoforged.neoforge.common.DeferredSpawnEggItem(ModEntities.TRANSFORMATIVE_SPIDER, 9145227, 16748640, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> CUSTOM_WOLF_SPAWN_EGG = ITEMS.register(
            "custom_wolf_spawn_egg", () -> new net.neoforged.neoforge.common.DeferredSpawnEggItem(ModEntities.TRANSFORMATIVE_WOLF, 9145227, 16765781, new Item.Properties()));
    public static final DeferredHolder<Item, ? extends Item> TRANSFORMATIVE_AXOLOTL_BUCKET = ITEMS.register(
            "transformative_axolotl_bucket", () -> new net.minecraft.world.item.MobBucketItem(
                    ModEntities.TRANSFORMATIVE_AXOLOTL.get(), net.minecraft.world.level.material.Fluids.WATER,
                    net.minecraft.sounds.SoundEvents.BUCKET_EMPTY_AXOLOTL, new Item.Properties().stacksTo(1)));

    private ModItems() {
    }
}
