package github.com.gengyoubo.sscnf.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.LinkedHashMap;
import java.util.Map;

@SuppressWarnings("deprecation")
public final class PlayerFormData implements github.com.gengyoubo.sscnf.api.PlayerFormData {
    public static final String ORIGINAL_BEFORE_ENABLE_FORM = "shape-shifter-curse:original_before_enable";
    public static final String ORIGINAL_SHIFTER_FORM = "shape-shifter-curse:original_shifter";
    private static final String FORM_ID_KEY = "FormId";
    private static final String PREVIOUS_FORM_ID_KEY = "PreviousFormId";
    private static final String FORM_GROUP_ID_KEY = "FormGroupId";
    private static final String FORM_TIER_KEY = "FormTier";
    private static final String CONTENT_ENABLED_KEY = "ContentEnabled";
    private static final String INSTINCT_VALUE_KEY = "InstinctValue";
    private static final String INSTINCT_RATE_KEY = "InstinctRate";
    private static final String INSTINCT_EFFECTS_KEY = "InstinctEffects";
    private static final String CURSED_MOON_APPLIED_KEY = "CursedMoonApplied";
    private static final String LAST_TRANSFORM_BY_CURE_KEY = "LastTransformByCure";
    private static final String BEFORE_CURSED_MOON_FORM_KEY = "BeforeCursedMoonAppliedForm";
    private static final String AFTER_CURSED_MOON_FORM_KEY = "AfterCursedMoonAppliedForm";
    private static final String TRANSFORMATIVE_EFFECT_FORM_KEY = "TransformativeEffectForm";
    private static final String TRANSFORMATIVE_EFFECT_TICKS_KEY = "TransformativeEffectTicks";
    private static final String UNLOCKED_PERKS_KEY = "UnlockedPerks";
    private static final String MANA_POOLS_KEY = "ManaPools";
    private static final String ITEM_STORES_KEY = "ItemStores";

    private boolean initialFormPending = true;

    public boolean takeInitialFormPending() {
        boolean pending = initialFormPending;
        initialFormPending = false;
        return pending;
    }

    private String formId = ORIGINAL_BEFORE_ENABLE_FORM;
    private String previousFormId = ORIGINAL_BEFORE_ENABLE_FORM;
    private String formGroupId = "shape-shifter-curse:base_form";
    private int formTier = -1;
    private boolean contentEnabled;
    private float instinctValue;
    private float instinctRate;
    private CompoundTag instinctEffects = new CompoundTag();
    private boolean cursedMoonApplied;
    private boolean lastTransformByCure;
    private String beforeCursedMoonAppliedForm;
    private String afterCursedMoonAppliedForm;
    private String transformativeEffectFormId;
    private int transformativeEffectTicks;
    private final Set<ResourceLocation> unlockedPerks = new LinkedHashSet<>();
    private final Map<String, Float> manaPools = new LinkedHashMap<>();
    private CompoundTag itemStores = new CompoundTag();

    @Override
    public String getFormId() {
        return formId;
    }

    @Override
    public void setFormId(String formId) {
        this.formId = formId == null || formId.isBlank() ? ORIGINAL_BEFORE_ENABLE_FORM : formId;
    }

    @Override
    public String getPreviousFormId() {
        return previousFormId;
    }

    @Override
    public void setPreviousFormId(String formId) {
        this.previousFormId = formId == null || formId.isBlank() ? ORIGINAL_BEFORE_ENABLE_FORM : formId;
    }

    @Override
    public String getFormGroupId() {
        return formGroupId;
    }

    public void setFormGroupId(String formGroupId) {
        this.formGroupId = formGroupId == null || formGroupId.isBlank()
                ? "shape-shifter-curse:base_form" : formGroupId;
    }

    @Override
    public int getFormTier() {
        return formTier;
    }

    public void setFormTier(int formTier) {
        this.formTier = formTier;
    }

    @Override
    public boolean isContentEnabled() {
        return contentEnabled;
    }

    public void setContentEnabled(boolean contentEnabled) {
        this.contentEnabled = contentEnabled;
    }

    @Override public float getInstinctValue() { return instinctValue; }

    @Override public void setInstinctValue(float instinctValue) { this.instinctValue = Math.max(0.0F, instinctValue); }

    @Override public float getInstinctRate() { return instinctRate; }

    @Override public void setInstinctRate(float instinctRate) { this.instinctRate = instinctRate; }

    @Override public CompoundTag getInstinctEffects() { return instinctEffects.copy(); }

    @Override public void setInstinctEffects(CompoundTag effects) { instinctEffects = effects == null ? new CompoundTag() : effects.copy(); }

    @Override public boolean isCursedMoonApplied() { return cursedMoonApplied; }

    @Override public void setCursedMoonApplied(boolean applied) { cursedMoonApplied = applied; }

    @Override public boolean wasLastTransformByCure() { return lastTransformByCure; }

    @Override public void setLastTransformByCure(boolean cured) { lastTransformByCure = cured; }

    @Override public String getBeforeCursedMoonAppliedForm() { return beforeCursedMoonAppliedForm; }

    @Override public void setBeforeCursedMoonAppliedForm(String formId) { beforeCursedMoonAppliedForm = formId; }

    @Override public String getAfterCursedMoonAppliedForm() { return afterCursedMoonAppliedForm; }

    @Override public void setAfterCursedMoonAppliedForm(String formId) { afterCursedMoonAppliedForm = formId; }

    @Override public String getTransformativeEffectFormId() { return transformativeEffectFormId; }

    @Override public void setTransformativeEffectFormId(String formId) { transformativeEffectFormId = formId; }

    @Override public int getTransformativeEffectTicks() { return transformativeEffectTicks; }

    @Override public void setTransformativeEffectTicks(int ticks) { transformativeEffectTicks = Math.max(0, ticks); }

    @Override
    public Set<ResourceLocation> getUnlockedPerks() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(unlockedPerks));
    }

    @Override
    public boolean hasUnlockedPerk(ResourceLocation perkId) {
        return perkId != null && unlockedPerks.contains(perkId);
    }

    @Override
    public void unlockPerk(ResourceLocation perkId) {
        unlockedPerks.add(java.util.Objects.requireNonNull(perkId, "perkId"));
    }

    @Override
    public void revokePerk(ResourceLocation perkId) {
        if (perkId != null) unlockedPerks.remove(perkId);
    }

    @Override
    public Map<String, Float> getManaPools() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(manaPools));
    }

    @Override
    public void setManaPool(String manaType, float amount) {
        if (manaType == null || manaType.isBlank()) return;
        manaPools.put(manaType, Math.max(0.0F, amount));
    }

    public void clearManaPools() {
        manaPools.clear();
    }

    @Override public CompoundTag getItemStores() { return itemStores.copy(); }

    @Override public void setItemStores(CompoundTag stores) {
        itemStores = stores == null ? new CompoundTag() : stores.copy();
    }

    @Override
    public void copyFrom(github.com.gengyoubo.sscnf.api.PlayerFormData other) {
        initialFormPending = false;
        setFormId(other.getFormId());
        setPreviousFormId(other.getPreviousFormId());
        setFormGroupId(other.getFormGroupId());
        setFormTier(other.getFormTier());
        setContentEnabled(other.isContentEnabled());
        setInstinctValue(other.getInstinctValue());
        setInstinctRate(other.getInstinctRate());
        setInstinctEffects(other.getInstinctEffects());
        setCursedMoonApplied(other.isCursedMoonApplied());
        setLastTransformByCure(other.wasLastTransformByCure());
        setBeforeCursedMoonAppliedForm(other.getBeforeCursedMoonAppliedForm());
        setAfterCursedMoonAppliedForm(other.getAfterCursedMoonAppliedForm());
        setTransformativeEffectFormId(other.getTransformativeEffectFormId());
        setTransformativeEffectTicks(other.getTransformativeEffectTicks());
        unlockedPerks.clear();
        unlockedPerks.addAll(other.getUnlockedPerks());
        manaPools.clear();
        manaPools.putAll(other.getManaPools());
        setItemStores(other.getItemStores());
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString(FORM_ID_KEY, formId);
        tag.putString(PREVIOUS_FORM_ID_KEY, previousFormId);
        tag.putString(FORM_GROUP_ID_KEY, formGroupId);
        tag.putInt(FORM_TIER_KEY, formTier);
        tag.putBoolean(CONTENT_ENABLED_KEY, contentEnabled);
        tag.putFloat(INSTINCT_VALUE_KEY, instinctValue);
        tag.putFloat(INSTINCT_RATE_KEY, instinctRate);
        tag.put(INSTINCT_EFFECTS_KEY, instinctEffects.copy());
        tag.putBoolean(CURSED_MOON_APPLIED_KEY, cursedMoonApplied);
        tag.putBoolean(LAST_TRANSFORM_BY_CURE_KEY, lastTransformByCure);
        if (beforeCursedMoonAppliedForm != null) {
            tag.putString(BEFORE_CURSED_MOON_FORM_KEY, beforeCursedMoonAppliedForm);
        }
        if (afterCursedMoonAppliedForm != null) {
            tag.putString(AFTER_CURSED_MOON_FORM_KEY, afterCursedMoonAppliedForm);
        }
        if (transformativeEffectFormId != null) {
            tag.putString(TRANSFORMATIVE_EFFECT_FORM_KEY, transformativeEffectFormId);
            tag.putInt(TRANSFORMATIVE_EFFECT_TICKS_KEY, transformativeEffectTicks);
        }
        ListTag perks = new ListTag();
        unlockedPerks.forEach(perkId -> perks.add(net.minecraft.nbt.StringTag.valueOf(perkId.toString())));
        tag.put(UNLOCKED_PERKS_KEY, perks);
        CompoundTag mana = new CompoundTag();
        manaPools.forEach(mana::putFloat);
        tag.put(MANA_POOLS_KEY, mana);
        tag.put(ITEM_STORES_KEY, itemStores.copy());
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        initialFormPending = false;
        if (tag.contains(FORM_ID_KEY)) {
            setFormId(tag.getString(FORM_ID_KEY));
        }
        if (tag.contains(PREVIOUS_FORM_ID_KEY)) {
            setPreviousFormId(tag.getString(PREVIOUS_FORM_ID_KEY));
        }
        if (tag.contains(FORM_GROUP_ID_KEY)) {
            setFormGroupId(tag.getString(FORM_GROUP_ID_KEY));
        }
        if (tag.contains(FORM_TIER_KEY)) {
            setFormTier(tag.getInt(FORM_TIER_KEY));
        }
        if (tag.contains(CONTENT_ENABLED_KEY)) {
            setContentEnabled(tag.getBoolean(CONTENT_ENABLED_KEY));
        }
        if (tag.contains(INSTINCT_VALUE_KEY)) setInstinctValue(tag.getFloat(INSTINCT_VALUE_KEY));
        if (tag.contains(INSTINCT_RATE_KEY)) setInstinctRate(tag.getFloat(INSTINCT_RATE_KEY));
        if (tag.contains(INSTINCT_EFFECTS_KEY)) setInstinctEffects(tag.getCompound(INSTINCT_EFFECTS_KEY));
        if (tag.contains(CURSED_MOON_APPLIED_KEY)) setCursedMoonApplied(tag.getBoolean(CURSED_MOON_APPLIED_KEY));
        if (tag.contains(LAST_TRANSFORM_BY_CURE_KEY)) setLastTransformByCure(tag.getBoolean(LAST_TRANSFORM_BY_CURE_KEY));
        beforeCursedMoonAppliedForm = tag.contains(BEFORE_CURSED_MOON_FORM_KEY)
                ? tag.getString(BEFORE_CURSED_MOON_FORM_KEY) : null;
        afterCursedMoonAppliedForm = tag.contains(AFTER_CURSED_MOON_FORM_KEY)
                ? tag.getString(AFTER_CURSED_MOON_FORM_KEY) : null;
        transformativeEffectFormId = tag.contains(TRANSFORMATIVE_EFFECT_FORM_KEY)
                ? tag.getString(TRANSFORMATIVE_EFFECT_FORM_KEY) : null;
        transformativeEffectTicks = tag.contains(TRANSFORMATIVE_EFFECT_TICKS_KEY)
                ? Math.max(0, tag.getInt(TRANSFORMATIVE_EFFECT_TICKS_KEY)) : 0;
        unlockedPerks.clear();
        if (tag.contains(UNLOCKED_PERKS_KEY, Tag.TAG_LIST)) {
            for (Tag perkTag : tag.getList(UNLOCKED_PERKS_KEY, Tag.TAG_STRING)) {
                ResourceLocation perkId = ResourceLocation.tryParse(perkTag.getAsString());
                if (perkId != null) unlockedPerks.add(perkId);
            }
        }
        manaPools.clear();
        if (tag.contains(MANA_POOLS_KEY, Tag.TAG_COMPOUND)) {
            CompoundTag mana = tag.getCompound(MANA_POOLS_KEY);
            for (String manaType : mana.getAllKeys()) {
                setManaPool(manaType, mana.getFloat(manaType));
            }
        }
        itemStores = tag.contains(ITEM_STORES_KEY, Tag.TAG_COMPOUND)
                ? tag.getCompound(ITEM_STORES_KEY).copy() : new CompoundTag();
    }
}
