package github.com.gengyoubo.sscnf.power;

import com.google.gson.JsonObject;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import github.com.gengyoubo.sscnf.ShapeShifterCurseNeoForge;
import github.com.gengyoubo.sscnf.api.SscApi;
import github.com.gengyoubo.sscnf.api.SscManaMaximumEvent;
import github.com.gengyoubo.sscnf.api.SscManaRecoveryEvent;
import github.com.gengyoubo.sscnf.api.registry.SscJavaRegistries;
import github.com.gengyoubo.sscnf.other.config.SscCommonConfig;
import github.com.gengyoubo.sscnf.form.FormManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Server-authoritative active, toggle, cooldown, charge and mana state for form powers. */
@SuppressWarnings("deprecation")
public final class FormActivePowerService {
    private static final float DEFAULT_MANA = 20.0F;
    private static final String FAMILIAR_FOX_MANA = "shape-shifter-curse:familiar_fox_mana";
    private static final String WEB_RESOURCE = "shape-shifter-curse:web_resource";
    private static final float FAMILIAR_FOX_MAX_MANA = 100.0F;
    private record ManaSnapshot(String type, float amount, float maximum) {}
    private static final Map<UUID, ManaSnapshot> LAST_MANA_SYNC = new HashMap<>();
    private static final java.util.Set<UUID> CALCULATING_MAXIMUM_MANA = new java.util.HashSet<>();
    private static final Map<UUID, Map<String, Boolean>> PRESSED_KEYS = new HashMap<>();
    private static final Map<UUID, Map<ResourceLocation, Integer>> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Map<ResourceLocation, ChargeState>> CHARGES = new HashMap<>();
    private static final Map<UUID, java.util.Set<ResourceLocation>> CLIENT_CHARGES = new HashMap<>();
    private static final class ChargeState {
        int ticks;
        int tier;
        int lastUseTick = Integer.MIN_VALUE;
    }
    private static final Map<UUID, Map<ResourceLocation, Double>> RESOURCES = new HashMap<>();
    private static final Map<UUID, Map<ResourceLocation, Double>> CLIENT_RESOURCES = new HashMap<>();
    private static final Map<UUID, Map<ResourceLocation, Boolean>> TOGGLES = new HashMap<>();
    private static final Map<UUID, Boolean> SPRINTING = new HashMap<>();
    private static final Map<UUID, Boolean> SPRINT_TO_SNEAK_TRIGGERED = new HashMap<>();
    /** One travel tick of protection for a launch issued while still touching water. */
    private static final Map<UUID, Boolean> WATER_LAUNCH_GRACE = new HashMap<>();
    private static final ResourceLocation JUMP_OUT_WATER = ResourceLocation.fromNamespaceAndPath(
            "shape-shifter-curse", "jump_out_water");

    private FormActivePowerService() {
    }

    /** Drops transient input state when a player leaves, so held/charged skills cannot survive a reconnect. */
    public static void clearTransientInput(Player player) {
        UUID id = player.getUUID();
        PRESSED_KEYS.remove(id);
        if (player.level().isClientSide) CLIENT_CHARGES.remove(id);
        else {
            Map<ResourceLocation, ChargeState> previous = CHARGES.remove(id);
            if (previous != null && player instanceof ServerPlayer serverPlayer)
                previous.keySet().forEach(power -> syncCharge(serverPlayer, power, new JsonObject(), false, 0));
        }
        WATER_LAUNCH_GRACE.remove(id);
        AirJumpService.clearTransient(player);
        FrostDiveService.clear(player);
        SurfaceGrappleService.cancel(player);
        if (!player.level().isClientSide) LAST_MANA_SYNC.remove(id);
    }

    public static void clearClientState() {
        CLIENT_CHARGES.clear();
        CLIENT_RESOURCES.clear();
    }

    /** An Origin replacement removes its power instances; discard the matching runtime state. */
    public static void onFormChanged(Player player) {
        UUID id = player.getUUID();
        clearTransientInput(player);
        COOLDOWNS.remove(id);
        RESOURCES.remove(id);
        TOGGLES.remove(id);
        SPRINTING.remove(id);
        SPRINT_TO_SNEAK_TRIGGERED.remove(id);
        // Fabric's ManaTypePower#onGained fills the active pool, whatever its type, whenever a
        // form gains it (every transformation, including commands).
        fillActiveManaPool(player);
    }

    /** Fabric's ManaTypePower#onRespawn also refills the active pool. */
    public static void onRespawn(ServerPlayer player) {
        fillActiveManaPool(player);
    }

    private static void fillActiveManaPool(Player player) {
        if (!player.level().isClientSide && hasActiveManaType(player)) setMana(player, maximumMana(player));
    }

    public static void setKeyPressed(ServerPlayer player, String key, boolean pressed) {
        if (!key.startsWith("key.shape-shifter-curse.") && !"key.jump".equals(key)
                && !"key.sprint".equals(key) && !SscJavaRegistries.isPowerKey(key)) {
            return;
        }
        Map<String, Boolean> keys = PRESSED_KEYS.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>());
        boolean wasPressed = keys.getOrDefault(key, false);
        keys.put(key, pressed);
        if ("key.jump".equals(key) && SscCommonConfig.ENABLE_MOVEMENT_DEBUG_LOGGING.get()) {
            ShapeShifterCurseNeoForge.LOGGER.info(
                    "[SSC-JUMP-DEBUG] input player={} pressed={} wasPressed={} form={} fluidHeight={} eyeInWater={} velocity={}",
                    player.getGameProfile().getName(), pressed, wasPressed,
                    FormManager.current(player).id(), player.getFluidHeight(FluidTags.WATER),
                    player.isEyeInFluid(FluidTags.WATER), player.getDeltaMovement());
        }
        if (!pressed && wasPressed) {
            CustomPowerTypeService.keyReleased(player, key);
        }
        if (pressed && !wasPressed) {
            // Add-on power types see every press of their key, before SSC's built-in handling.
            CustomPowerTypeService.keyPressed(player, key);
            if (FrostDiveService.tryStart(player, key)) return;
            if (toggle(player, key)) {
                return;
            }
            // A surface-water active_self power (jump_out_water) must win over the
            // generic air-jump branch. Water-surface players are not onGround(), so
            // checking air jump first made the original SSC launch unreachable.
            if ("key.jump".equals(key) && triggerActive(player, key)) {
                return;
            }
            if ("key.jump".equals(key) && AirJumpService.tryJump(player)) return;
            triggerActive(player, key);
        }
    }

    public static void tick(Player player) {
        if (player.level().isClientSide) {
            return;
        }
        AirJumpService.tick(player);
        if (player instanceof ServerPlayer serverPlayer) FrostDiveService.tick(serverPlayer);
        if (FAMILIAR_FOX_MANA.equals(manaType(player))
                && github.com.gengyoubo.sscnf.other.cursedmoon.CursedMoonService
                .isInCursedMoon(player.level()) && mana(player) < maximumMana(player)) {
            gainMana(player, 0.02F);
        }
        tickCooldowns(player.getUUID());
        LevitatePowerService.tick(player, PRESSED_KEYS.getOrDefault(player.getUUID(), Map.of())
                .getOrDefault("key.jump", false));
        tickChargeReleases(player);
        Map<ResourceLocation, Boolean> toggles = TOGGLES.get(player.getUUID());
        if (toggles != null) {
            toggles.keySet().removeIf(toggleId -> !FormPowerRegistry.has(player, toggleId));
        }
        boolean wasSprinting = SPRINTING.getOrDefault(player.getUUID(), false);
        SPRINTING.put(player.getUUID(), player.isSprinting());
        if (!wasSprinting && player.isSprinting()) {
            SPRINT_TO_SNEAK_TRIGGERED.put(player.getUUID(), false);
        }
        if (player.isSprinting() && !wasSprinting && player instanceof ServerPlayer serverPlayer) {
            triggerActive(serverPlayer, "key.sprint");
        }
        // Fabric's SprintingStateTracker checks the prior sprint tick against
        // the current Shift input, and fires once per sprint episode. Crouch
        // pose is not equivalent to Shift while an axolotl is crawling.
        if (wasSprinting && player.isShiftKeyDown()
                && !SPRINT_TO_SNEAK_TRIGGERED.getOrDefault(player.getUUID(), false)
                && player instanceof ServerPlayer serverPlayer) {
            SPRINT_TO_SNEAK_TRIGGERED.put(player.getUUID(), true);
            FormPowerRegistry.visitActive(serverPlayer, (id, power) -> {
                if ("shape-shifter-curse:action_on_sprinting_to_sneaking".equals(FormPowerRegistry.typeOf(power))
                        && FormPowerRuntime.test(serverPlayer, serverPlayer, power.getAsJsonObject("entity_condition"))) {
                    FormPowerRuntime.execute(serverPlayer, serverPlayer, power.getAsJsonObject("entity_action"));
                }
            });
        }
        Map<String, Boolean> keys = PRESSED_KEYS.get(player.getUUID());
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        // Flight continues with no key state, so this runs before the null check below.
        SurfaceGrappleService.tick(serverPlayer, keys == null ? Map.of() : keys);
        if (keys == null) {
            return;
        }
        keys.forEach((key, pressed) -> {
            if (pressed) {
                triggerContinuousActive(serverPlayer, key);
                charge(serverPlayer, key);
                CustomPowerTypeService.keyHeld(serverPlayer, key);
            }
        });
    }

    public static boolean hasMana(Player player, float amount) {
        return mana(player) >= amount;
    }

    public static boolean hasWebMana(Player player) {
        return WEB_RESOURCE.equals(manaType(player));
    }

    public static boolean hasFamiliarFoxMana(Player player) {
        return FAMILIAR_FOX_MANA.equals(manaType(player));
    }

    public static boolean isToggleActive(Player player, ResourceLocation id) {
        FormPowerDefinition definition = FormPowerRegistry.all().get(id);
        boolean defaultValue = definition != null
                && FormPowerRuntime.booleanValue(definition.data(), "active_by_default", false);
        return TOGGLES.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>())
                .getOrDefault(id, defaultValue);
    }

    private static boolean toggle(ServerPlayer player, String key) {
        final boolean[] changed = {false};
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape_shifter_curse:toggle".equals(FormPowerRegistry.typeOf(power))
                    || !key.equals(FormPowerRuntime.stringValue(power.getAsJsonObject("key"), "key", ""))) return;
            boolean active = isToggleActive(player, id);
            TOGGLES.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>()).put(id, !active);
            changed[0] = true;
        });
        return changed[0];
    }

    public static void triggerVanillaKey(Player player, String key) {
        if (player instanceof ServerPlayer serverPlayer) {
            triggerActive(serverPlayer, key);
        }
    }

    /**
     * Runs the surface jump after vanilla has completed LivingEntity.travel().
     * The normal LivingTickEvent is before travel, so a launch applied there is
     * still treated as water motion and its Y component is damped by vanilla.
     */
    public static void postTravelTick(Player player) {
        if (player.level().isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return;
        }

        UUID id = player.getUUID();
        boolean touchingWater = player.getFluidHeight(FluidTags.WATER) > 0.0D;
        if (!touchingWater) {
            WATER_LAUNCH_GRACE.remove(id);
        }

        Map<String, Boolean> keys = PRESSED_KEYS.get(id);
        if (keys == null || !keys.getOrDefault("key.jump", false)) {
            return;
        }

        triggerContinuousJumpOutWater(serverPlayer);
        logJumpState(serverPlayer);
    }

    private static void logJumpState(ServerPlayer player) {
        if (!SscCommonConfig.ENABLE_MOVEMENT_DEBUG_LOGGING.get()) {
            return;
        }
        ShapeShifterCurseNeoForge.LOGGER.info(
                "[SSC-JUMP-DEBUG] state stage={} player={} y={} yOld={} deltaY={} velocity={} onGround={} verticalCollision={} horizontalCollision={} fluidHeight={} eyeInWater={}",
                "post-travel-state", player.getGameProfile().getName(), player.getY(), player.yOld,
                player.getY() - player.yOld, player.getDeltaMovement(), player.onGround(),
                player.verticalCollision, player.horizontalCollision,
                player.getFluidHeight(FluidTags.WATER), player.isEyeInFluid(FluidTags.WATER));
    }

    /** Called by LivingEntity.travel() to preserve a just-issued surface launch. */
    public static void armWaterLaunchGrace(Player player) {
        if (player.getFluidHeight(FluidTags.WATER) > 0.0D) {
            WATER_LAUNCH_GRACE.put(player.getUUID(), Boolean.TRUE);
        }
    }

    /** Consumes the one-tick vertical water-damping bypass. */
    public static boolean consumeWaterLaunchGrace(Player player) {
        if (player.level().isClientSide) {
            return false;
        }
        return WATER_LAUNCH_GRACE.remove(player.getUUID()) != null;
    }

    public static void consumeMana(Player player, float amount) {
        if (player.level().isClientSide || !Float.isFinite(amount) || amount < 0.0F || !hasMana(player, amount)) {
            return;
        }
        setMana(player, mana(player) - amount);
    }

    /** Recover mana through the add-on hook, clamped to the currently selected pool's maximum. */
    public static void gainMana(Player player, float amount) {
        if (!(player instanceof ServerPlayer serverPlayer) || !Float.isFinite(amount) || amount <= 0.0F) return;
        SscManaRecoveryEvent event = new SscManaRecoveryEvent(serverPlayer, ResourceLocation.parse(manaType(player)), amount);
        if (net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(event).isCanceled() || event.getAmount() == 0.0F) return;
        setMana(player, mana(player) + event.getAmount());
    }

    /** Returns the current Apoli resource value. Cooldowns are exposed as 0/1, as in the source data. */
    public static double resource(Player player, ResourceLocation id) {
        FormPowerDefinition definition = FormPowerRegistry.all().get(id);
        if (definition != null && "shape_shifter_curse:cooldown".equals(FormPowerRegistry.typeOf(definition.data()))) {
            return isOnCooldown(player, id) ? 1.0D : 0.0D;
        }
        return (player.level().isClientSide ? CLIENT_RESOURCES : RESOURCES).computeIfAbsent(player.getUUID(), ignored -> new HashMap<>())
                .computeIfAbsent(id, ignored -> defaultResource(definition));
    }

    public static void modifyResource(Player player, ResourceLocation id, JsonObject modifier) {
        FormPowerDefinition definition = FormPowerRegistry.all().get(id);
        if (definition != null && "shape_shifter_curse:cooldown".equals(FormPowerRegistry.typeOf(definition.data()))) {
            if (FormPowerRuntime.doubleValue(modifier, "value", 0.0D) >= 1.0D) {
                triggerCooldown(player, id);
            }
            return;
        }
        double current = resource(player, id);
        double value = switch (FormPowerRuntime.stringValue(modifier, "operation", "addition")) {
            case "set_total" -> FormPowerRuntime.doubleValue(modifier, "value", current);
            default -> FormPowerRuntime.applyModifier(current, modifier);
        };
        double min = definition == null ? Double.NEGATIVE_INFINITY : FormPowerRuntime.doubleValue(definition.data(), "min", 0.0D);
        double max = definition == null ? Double.POSITIVE_INFINITY : FormPowerRuntime.doubleValue(definition.data(), "max", Double.MAX_VALUE);
        double clamped = Math.max(min, Math.min(max, value));
        var map = (player.level().isClientSide ? CLIENT_RESOURCES : RESOURCES).computeIfAbsent(player.getUUID(), ignored -> new HashMap<>());
        Double previous = map.put(id, clamped);
        if (player instanceof ServerPlayer serverPlayer && (previous == null || Double.compare(previous, clamped) != 0))
            net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(serverPlayer, new github.com.gengyoubo.sscnf.network.PowerResourcePacket(id, clamped));
    }

    public static void acceptClientResource(Player player, ResourceLocation id, double value) {
        CLIENT_RESOURCES.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>()).put(id, value);
    }
    public static void synchronizeResources(ServerPlayer player) {
        RESOURCES.getOrDefault(player.getUUID(), Map.of()).forEach((id, value) ->
                net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player, new github.com.gengyoubo.sscnf.network.PowerResourcePacket(id, value)));
    }

    public static void triggerCooldown(Player player, ResourceLocation id) {
        FormPowerDefinition definition = FormPowerRegistry.all().get(id);
        if (definition != null) {
            startCooldown(player, id, FormPowerRuntime.intValue(definition.data(), "cooldown", 0));
        }
    }

    public static float mana(Player player) {
        return Math.max(0.0F, Math.min(maximumMana(player), storedMana(player)));
    }

    private static float storedMana(Player player) {
        String type = manaType(player);
        float initial = FAMILIAR_FOX_MANA.equals(type) ? 0.0F
                : WEB_RESOURCE.equals(type) ? 100.0F : DEFAULT_MANA;
        return SscApi.currentForm(player).map(data -> data.getManaPools().getOrDefault(type, initial))
                .orElse(initial);
    }

    /** The retained SSC data expresses mana thresholds as a 0..1 fraction. */
    public static float manaPercent(Player player) {
        return mana(player) / maximumMana(player);
    }

    public static float maximumMana(Player player) {
        String type = manaType(player);
        float base = FAMILIAR_FOX_MANA.equals(type) ? FAMILIAR_FOX_MAX_MANA
                : WEB_RESOURCE.equals(type) ? 100.0F : DEFAULT_MANA;
        Map<String, Float> bonuses = new HashMap<>();
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape-shifter-curse:mana_attribute".equals(FormPowerRegistry.typeOf(power))
                    || !FormPowerRuntime.test(player, player, power.getAsJsonObject("condition"))) return;
            JsonObject modifier = power.getAsJsonObject("max_mana_modifier");
            if (modifier != null) bonuses.merge(FormPowerRuntime.stringValue(power, "modifierID", id.toString()),
                    FormPowerRuntime.floatValue(modifier, "add", 0.0F), Math::max);
        });
        for (float amount : bonuses.values()) base += amount;
        float maximum = Math.max(1.0F, base);
        if (!(player instanceof ServerPlayer serverPlayer) || !hasActiveManaType(player)
                || !CALCULATING_MAXIMUM_MANA.add(player.getUUID())) return maximum;
        try {
            SscManaMaximumEvent event = new SscManaMaximumEvent(serverPlayer, ResourceLocation.parse(type), maximum);
            net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(event);
            return Math.max(1.0F, event.getMaximum());
        } finally {
            CALCULATING_MAXIMUM_MANA.remove(player.getUUID());
        }
    }

    /** Direct assignment, bypassing recovery hooks (also used for refills and refunds). */
    public static void setMana(Player player, float value) {
        if (player.level().isClientSide || !Float.isFinite(value)) return;
        String type = manaType(player);
        float maximum = maximumMana(player);
        float clamped = Math.max(0.0F, Math.min(maximum, value));
        SscApi.currentForm(player).ifPresent(data -> data.setManaPool(type, clamped));
        if (player instanceof ServerPlayer serverPlayer) {
            sendManaSnapshot(serverPlayer, new ManaSnapshot(type, clamped, maximum), true);
        }
    }

    /** Pushes the active pool after login, respawn, dimension changes and form swaps. */
    public static void synchronizeMana(ServerPlayer player) {
        synchronizeMana(player, true);
    }

    /** End-of-tick update for conditional capacity changes, without sending unchanged snapshots. */
    public static void refreshMana(ServerPlayer player) {
        synchronizeMana(player, false);
    }

    private static void synchronizeMana(ServerPlayer player, boolean force) {
        if (!hasActiveManaType(player)) {
            sendManaSnapshot(player, new ManaSnapshot("", 0.0F, DEFAULT_MANA), force);
            return;
        }
        String type = manaType(player);
        float maximum = maximumMana(player);
        float current = storedMana(player);
        float clamped = Math.max(0.0F, Math.min(maximum, current));
        if (current != clamped) SscApi.currentForm(player).ifPresent(data -> data.setManaPool(type, clamped));
        sendManaSnapshot(player, new ManaSnapshot(type, clamped, maximum), force);
    }

    private static void sendManaSnapshot(ServerPlayer player, ManaSnapshot snapshot, boolean force) {
        if (!force && snapshot.equals(LAST_MANA_SYNC.get(player.getUUID()))) return;
        github.com.gengyoubo.sscnf.network.ModNetwork.sendManaSync(
                player, snapshot.type(), snapshot.amount(), snapshot.maximum());
        LAST_MANA_SYNC.put(player.getUUID(), snapshot);
    }

    public static boolean hasActiveManaType(Player player) {
        final boolean[] found = {false};
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if ("shape-shifter-curse:mana_type_power".equals(FormPowerRegistry.typeOf(power)) && power.has("mana_type")) {
                found[0] = true;
            }
        });
        return found[0];
    }

    public static String manaType(Player player) {
        final String[] type = {"shape-shifter-curse:generic_mana"};
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if ("shape-shifter-curse:mana_type_power".equals(FormPowerRegistry.typeOf(power)) && power.has("mana_type")) {
                type[0] = power.get("mana_type").getAsString();
            }
        });
        return type[0];
    }

    private static boolean triggerActive(ServerPlayer player, String key) {
        final boolean[] triggered = {false};
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape_shifter_curse:active_self".equals(FormPowerRegistry.typeOf(power)) || usesKey(power, key)
                    || isOnCooldown(player, id)) {
                return;
            }
            // The efficiency perk replaces the original water burst with a child
            // active power. A fountain belt replaces that burst too, while the
            // perk's separate attack improvement must remain active.
            if ("shape-shifter-curse:perks/axolotl_water_magic_efficiency".equals(id.toString())
                    && (FormPowerRegistry.has(player, ResourceLocation.fromNamespaceAndPath(
                            "shape-shifter-curse", "form_axolotl_fountain_belt_trinket"))
                    || FormPowerRegistry.has(player, ResourceLocation.fromNamespaceAndPath(
                            "shape-shifter-curse", "form_axolotl_fountain_belt_trinket_plus")))) {
                return;
            }
            JsonObject condition = power.has("condition") ? power.getAsJsonObject("condition") : power.getAsJsonObject("entity_condition");
            boolean jumpOutWater = JUMP_OUT_WATER.equals(id);
            boolean conditionMet = FormPowerRuntime.test(player, player, condition);
            if (jumpOutWater && SscCommonConfig.ENABLE_MOVEMENT_DEBUG_LOGGING.get()) {
                ShapeShifterCurseNeoForge.LOGGER.info(
                        "[SSC-JUMP-DEBUG] press-candidate player={} condition={} fluidHeight={} eyeInWater={} velocityBefore={}",
                        player.getGameProfile().getName(), conditionMet,
                        player.getFluidHeight(FluidTags.WATER), player.isEyeInFluid(FluidTags.WATER),
                        player.getDeltaMovement());
            }
            if (!conditionMet) {
                return;
            }
            // Surface launch is deliberately deferred until PlayerTickEvent.END,
            // after vanilla travel has finished applying water damping.
            if (jumpOutWater) {
                return;
            }
            Vec3 before = player.getDeltaMovement();
            FormPowerRuntime.execute(player, player, power.getAsJsonObject("entity_action"));
            if (!before.equals(player.getDeltaMovement())) {
                player.hurtMarked = true;
                player.connection.send(new ClientboundSetEntityMotionPacket(player));
            }
            startCooldown(player, id, FormPowerRuntime.intValue(power, "cooldown", 0));
            triggered[0] = true;
        });
        return triggered[0];
    }

    /** Runs only active_self powers whose key explicitly has continuous=true. */
    private static void triggerContinuousActive(ServerPlayer player, String key) {
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape_shifter_curse:active_self".equals(FormPowerRegistry.typeOf(power))
                    || usesKey(power, key)
                    || !power.getAsJsonObject("key").has("continuous")
                    || !power.getAsJsonObject("key").get("continuous").getAsBoolean()
                    || isOnCooldown(player, id)) {
                return;
            }
            JsonObject condition = power.has("condition")
                    ? power.getAsJsonObject("condition") : power.getAsJsonObject("entity_condition");
            boolean jumpOutWater = JUMP_OUT_WATER.equals(id);
            if (jumpOutWater) {
                return;
            }
            boolean conditionMet = FormPowerRuntime.test(player, player, condition);
            if (!conditionMet) {
                return;
            }
            FormPowerRuntime.execute(player, player, power.getAsJsonObject("entity_action"));
            startCooldown(player, id, FormPowerRuntime.intValue(power, "cooldown", 0));
        });
    }

    /** Executes only jump_out_water after the entity has finished vanilla travel. */
    private static void triggerContinuousJumpOutWater(ServerPlayer player) {
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!JUMP_OUT_WATER.equals(id)
                    || !"shape_shifter_curse:active_self".equals(FormPowerRegistry.typeOf(power))
                    || usesKey(power, "key.jump")
                    || !power.getAsJsonObject("key").has("continuous")
                    || !power.getAsJsonObject("key").get("continuous").getAsBoolean()
                    || isOnCooldown(player, id)) {
                return;
            }
            JsonObject condition = power.has("condition")
                    ? power.getAsJsonObject("condition") : power.getAsJsonObject("entity_condition");
            boolean conditionMet = FormPowerRuntime.test(player, player, condition);
            if (!conditionMet) {
                return;
            }
            Vec3 before = player.getDeltaMovement();
            if (SscCommonConfig.ENABLE_MOVEMENT_DEBUG_LOGGING.get()) {
                ShapeShifterCurseNeoForge.LOGGER.info(
                        "[SSC-JUMP-DEBUG] post-travel-candidate player={} fluidHeight={} velocityBefore={}",
                        player.getGameProfile().getName(), player.getFluidHeight(FluidTags.WATER), before);
            }
            FormPowerRuntime.execute(player, player, power.getAsJsonObject("entity_action"));
            double maxY = FormPowerRuntime.doubleValue(power, "max_y_velocity", -1.0D);
            if (power.has("max_y_velocity") && maxY >= 0.0D && player.getDeltaMovement().y > maxY) {
                Vec3 capped = player.getDeltaMovement();
                player.setDeltaMovement(capped.x, maxY, capped.z);
            }
            armWaterLaunchGrace(player);
            syncLaunchVelocity(player);
            startCooldown(player, id, FormPowerRuntime.intValue(power, "cooldown", 0));
            if (SscCommonConfig.ENABLE_MOVEMENT_DEBUG_LOGGING.get()) {
                ShapeShifterCurseNeoForge.LOGGER.info(
                        "[SSC-JUMP-DEBUG] post-travel-fired player={} velocityAfter={} deltaY={}",
                        player.getGameProfile().getName(), player.getDeltaMovement(),
                        player.getDeltaMovement().y - before.y);
            }
        });
    }

    /**
     * The server changes a player velocity, but the local client also predicts
     * player movement. Send the launch explicitly so its next movement tick
     * cannot continue with the ordinary swim trajectory.
     */
    private static void syncLaunchVelocity(ServerPlayer player) {
        player.connection.send(new ClientboundSetEntityMotionPacket(player));
    }

    private static void charge(ServerPlayer player, String key) {
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape-shifter-curse:charge_action".equals(FormPowerRegistry.typeOf(power)) || usesKey(power, key)
                    || isOnCooldown(player, id)) {
                return;
            }
            Map<ResourceLocation, ChargeState> states = CHARGES.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>());
            ChargeState state = states.get(id);
            if (state == null) {
                if (!FormPowerRuntime.test(player, player, power.getAsJsonObject("start_condition"))) return;
                FormPowerRuntime.execute(player, player, power.getAsJsonObject("start_action"));
                state = new ChargeState();
                states.put(id, state);
                syncCharge(player, id, power, true, 0);
            }
            state.lastUseTick = player.tickCount;
            state.ticks++;
            for (int tier = 0; tier < 10; tier++) {
                String prefix = "tier" + tier + "_";
                if (!FormPowerRuntime.booleanValue(power, prefix + "enable", tier == 0)) break;
                boolean justCompleted = false;
                if (state.tier + 1 == tier) {
                    JsonObject canCharge = power.getAsJsonObject(prefix + "can_charge_condition");
                    if (canCharge != null && !FormPowerRuntime.test(player, player, canCharge)) {
                        state.ticks--;
                    } else {
                        FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "charge_tick_action"));
                        int required = FormPowerRuntime.intValue(power, prefix + "charge_time", -1);
                        if (state.ticks >= required) {
                            JsonObject condition = power.getAsJsonObject(prefix + "condition");
                            if (condition != null && !FormPowerRuntime.test(player, player, condition)) {
                                state.ticks = required - 1;
                            } else {
                                FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "charge_complete_action"));
                                state.tier = tier;
                                justCompleted = true;
                                syncCharge(player, id, power, true, tier);
                            }
                        }
                    }
                }
                if (state.tier == tier) {
                    FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "tick_action"));
                }
                if (state.tier >= tier) {
                    FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "charge_complete_tick_action"));
                }
                JsonObject autoFire = power.getAsJsonObject(prefix + "auto_fire_condition");
                if (justCompleted && autoFire != null && FormPowerRuntime.test(player, player, autoFire)) {
                    fireCharge(player, id, power, state);
                    states.remove(id);
                    syncCharge(player, id, power, false, 0);
                    break;
                }
            }
        });
    }

    /** Fabric fires once no onUse call has arrived for more than two power ticks. */
    private static void tickChargeReleases(Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) return;
        Map<ResourceLocation, ChargeState> states = CHARGES.get(player.getUUID());
        if (states == null || states.isEmpty()) return;
        Map<String, Boolean> keys = PRESSED_KEYS.getOrDefault(player.getUUID(), Map.of());
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!"shape-shifter-curse:charge_action".equals(FormPowerRegistry.typeOf(power))) return;
            ChargeState state = states.get(id);
            if (state == null) return;
            String key = FormPowerRuntime.stringValue(power.getAsJsonObject("key"), "key", "");
            if (!keys.getOrDefault(key, false) && player.tickCount - state.lastUseTick > 2) {
                if (!isOnCooldown(player, id)) fireCharge(serverPlayer, id, power, state);
                states.remove(id);
                syncCharge(serverPlayer, id, power, false, 0);
            }
        });
    }

    public static boolean isCharging(Player player, ResourceLocation id) {
        String path = id.getPath();
        ResourceLocation parent = path.endsWith("_charge") ? ResourceLocation.fromNamespaceAndPath(id.getNamespace(), path.substring(0, path.length() - 7)) : id;
        if (player.level().isClientSide) {
            var states = CLIENT_CHARGES.getOrDefault(player.getUUID(), java.util.Set.of());
            return states.contains(id) || states.contains(parent);
        }
        var states = CHARGES.getOrDefault(player.getUUID(), Map.of());
        return states.containsKey(id) || states.containsKey(parent);
    }
    public static void acceptClientCharge(Player player, ResourceLocation id, boolean charging) {
        var states = CLIENT_CHARGES.computeIfAbsent(player.getUUID(), ignored -> new java.util.HashSet<>());
        if (charging) states.add(id); else states.remove(id);
    }
    /** Also carries the completed tier under the power's {@code charge_power_id} for the HUD. */
    private static void syncCharge(ServerPlayer player, ResourceLocation id, JsonObject power,
                                   boolean charging, int tier) {
        String chargeKey = FormPowerRuntime.stringValue(power, "charge_power_id", id.toString());
        if (player.connection != null && player.connection.isAcceptingMessages())
            net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player,
                    new github.com.gengyoubo.sscnf.network.ChargeStatePacket(id, charging, chargeKey, tier));
    }

    private static void fireCharge(ServerPlayer player, ResourceLocation id, JsonObject power, ChargeState state) {
        if (state.ticks <= 0) return;
        for (int tier = 0; tier < 10; tier++) {
            String prefix = "tier" + tier + "_";
            if (!FormPowerRuntime.booleanValue(power, prefix + "enable", tier == 0)) break;
            if (state.tier == tier) {
                FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "use_action"));
                startCooldown(player, id, FormPowerRuntime.intValue(power, prefix + "cooldown", 0));
            }
            if (state.tier >= tier) {
                FormPowerRuntime.execute(player, player, power.getAsJsonObject(prefix + "charge_complete_use_action"));
            }
        }
        state.tier = 0;
        state.ticks = 0;
    }

    private static boolean usesKey(JsonObject power, String key) {
        return !power.has("key") || !power.get("key").isJsonObject()
                || !key.equals(FormPowerRuntime.stringValue(power.getAsJsonObject("key"), "key", ""));
    }

    private static boolean isOnCooldown(Player player, ResourceLocation id) {
        return COOLDOWNS.getOrDefault(player.getUUID(), Map.of()).getOrDefault(id, 0) > 0;
    }

    /** Claims an Apoli cooldown after every condition has passed. */
    public static boolean usePowerCooldown(Player player, ResourceLocation id, int ticks) {
        if (isOnCooldown(player, id)) return false;
        startCooldown(player, id, ticks);
        return true;
    }

    private static void startCooldown(Player player, ResourceLocation id, int ticks) {
        if (ticks > 0) {
            COOLDOWNS.computeIfAbsent(player.getUUID(), ignored -> new HashMap<>()).put(id, ticks);
        }
    }

    private static double defaultResource(FormPowerDefinition definition) {
        return definition == null ? 0.0D : FormPowerRuntime.doubleValue(definition.data(), "start_value",
                FormPowerRuntime.doubleValue(definition.data(), "min", 0.0D));
    }

    private static void tickCooldowns(UUID playerId) {
        Map<ResourceLocation, Integer> cooldowns = COOLDOWNS.get(playerId);
        if (cooldowns != null) {
            cooldowns.replaceAll((id, ticks) -> ticks - 1);
            cooldowns.entrySet().removeIf(entry -> entry.getValue() <= 0);
        }
    }
}
