package github.com.gengyoubo.sscnf.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import github.com.gengyoubo.sscnf.ShapeShifterCurseNeoForge;
import github.com.gengyoubo.sscnf.form.FormDefinition;
import github.com.gengyoubo.sscnf.form.FormManager;
import github.com.gengyoubo.sscnf.power.FormPowerRegistry;
import github.com.gengyoubo.sscnf.power.FormPowerRuntime;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;

import java.util.Optional;

/**
 * Forge counterpart of Fabric's first-person form rendering
 * ({@code FormRenderFeature#rFPM_PartA}/{@code rFPM_PartB} plus
 * {@code DefaultModelAnimationSystem#beforeRenderFirstPerson}/
 * {@code processAnimationFirstPerson}).
 *
 * <p>Fabric chain, mirrored here: resolve the target GeoBone, reset it, copy the
 * vanilla first-person arm part pose onto it (position negated, arm pivot offset,
 * rotation with Y/Z inverted), then {@code renderRecursively} just that bone subtree
 * via {@code renderGeoBone}. In first person the arm motion comes from the hand
 * matrix, so the clip is deliberately NOT applied here, exactly like Fabric.</p>
 */
@net.neoforged.fml.common.EventBusSubscriber(modid = ShapeShifterCurseNeoForge.MOD_ID, value = Dist.CLIENT)
public final class FormFirstPersonArmEvents {
    private FormFirstPersonArmEvents() {
    }

    /** Also receives canceled events so another renderer cannot make form arms reappear. */
    @SubscribeEvent(receiveCanceled = true)
    public static void renderArm(RenderArmEvent event) {
        AbstractClientPlayer player = event.getPlayer();
        Minecraft minecraft = Minecraft.getInstance();
        if (!FirstPersonModelCompat.isLocalFirstPerson(player)) {
            return;
        }
        boolean hideArms = shouldHideArms(player);
        if (hideArms) {
            event.setCanceled(true);
            return;
        }

        if (!github.com.gengyoubo.sscnf.other.config.SscClientConfig.FIRST_PERSON_FORM_ARMS.get()) return;
        FormDefinition form = FormManager.current(player);
        if (!form.hasFlag("special_form") && form.stage() <= 0) {
            return;
        }

        FormGeoRenderer renderer = FormClientRenderEvents.rendererFor(form);
        if (renderer == null
                || !(minecraft.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer playerRenderer)) {
            return;
        }
        FormGeoModel model = (FormGeoModel) renderer.getGeoModel();
        boolean right = event.getArm() == HumanoidArm.RIGHT;
        // Mirrors rFPM_PartA: the vanilla arm is hidden when the form hides it.
        if (model.isVanillaPartHidden(right ? "rightArm" : "leftArm")) {
            event.setCanceled(true);
        }

        // Mirrors beforeRenderFirstPerson: resolve the mapped arm bone
        // (biped arms by default, overridable through first_person_render).
        BakedGeoModel baked = model.getBakedModel(model.modelResource());
        if (baked == null) {
            return;
        }
        model.getAnimationProcessor().setActiveModel(baked);
        Optional<GeoBone> armBone = model.getBone(model.firstPersonArmBone(right));
        // Mirrors the null branch: nothing to draw for this arm.
        if (armBone.isEmpty()) {
            return;
        }
        GeoBone geoBone = armBone.get();

        // Mirrors processAnimationFirstPerson: reset the bone to its initial state,
        // then copy the vanilla first-person arm part pose onto it.
        //
        // NeoForge posts RenderArmEvent from renderRightHand/renderLeftHand *before* vanilla's
        // renderHand runs setupAnim(0...) and zeroes xRot, so the shared PlayerModel still holds
        // whatever pose the last world/inventory render (or a form clip, e.g. Avali's wing
        // spread) left on it. Fabric read the part after that reset; use the same reset pose:
        // HumanoidModel#setupAnim with zero inputs plus bobModelPart(age 0), then xRot = 0.
        FirstPersonArmPose armPart = FirstPersonArmPose.vanilla(right);
        FormGeoModel.resetToInitial(geoBone);
        geoBone.setPosX(geoBone.getPosX() + (-armPart.x()));
        geoBone.setPosY(geoBone.getPosY() + (-armPart.y()));
        geoBone.setPosZ(geoBone.getPosZ() + (-armPart.z()));
        geoBone.setPosX(geoBone.getPosX() + (right ? -5.0F : 5.0F));
        geoBone.setPosY(geoBone.getPosY() + 2.0F);
        geoBone.setRotX(armPart.xRot());
        geoBone.setRotY(armPart.yRot());
        geoBone.setRotZ(armPart.zRot());
        geoBone.setRotY(-geoBone.getRotY());
        geoBone.setRotZ(-geoBone.getRotZ());

        renderer.setPlayer(player);
        FormGeoAnimatable animatable = renderer.getAnimatable();
        if (animatable == null) {
            return;
        }
        float partialTick = minecraft.getTimer().getGameTimeDeltaPartialTick(true);
        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        try {
            poseStack.mulPose(Axis.XP.rotationDegrees(180.0F));
            poseStack.translate(0.0D, -1.51D, 0.0D);

            ResourceLocation texture = renderer.getTextureLocation(animatable);
            RenderType renderType = RenderType.entityTranslucent(texture);
            VertexConsumer buffer = event.getMultiBufferSource().getBuffer(renderType);

            renderer.renderRecursively(
                    poseStack,
                    animatable,
                    geoBone,
                    renderType,
                    event.getMultiBufferSource(),
                    buffer,
                    false,
                    partialTick,
                    event.getPackedLight(),
                    OverlayTexture.NO_OVERLAY,
                    -1);
        } catch (RuntimeException ignored) {
            // A first-person arm must never break hand rendering.
        } finally {
            poseStack.popPose();
        }
    }

    /** The arm part pose vanilla renderHand draws an empty first-person hand with. */
    private record FirstPersonArmPose(float x, float y, float z, float xRot, float yRot, float zRot) {
        static FirstPersonArmPose vanilla(boolean right) {
            // setupAnim: x = -/+5, y = 2, z = 0, rotations 0; bobModelPart(age 0) adds zRot +/-0.1.
            return new FirstPersonArmPose(right ? -5.0F : 5.0F, 2.0F, 0.0F, 0.0F, 0.0F, right ? 0.1F : -0.1F);
        }
    }

    public static boolean shouldHideArms(AbstractClientPlayer player) {
        if (github.com.gengyoubo.sscnf.other.config.SscClientConfig.IGNORE_HIDE_ARMS.get()) return false;
        final boolean[] hide = {false};
        FormPowerRegistry.visitActive(player, (id, power) -> {
            if (!hide[0] && "shape-shifter-curse:no_render_arm".equals(FormPowerRegistry.typeOf(power))
                    && FormPowerRuntime.test(player, player, power.getAsJsonObject("condition"))) {
                hide[0] = true;
            }
        });
        return hide[0];
    }
}
