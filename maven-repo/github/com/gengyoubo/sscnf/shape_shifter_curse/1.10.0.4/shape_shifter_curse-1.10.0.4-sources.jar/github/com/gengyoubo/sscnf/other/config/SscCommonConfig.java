package github.com.gengyoubo.sscnf.other.config;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

/** Gameplay and diagnostics options in Forge's common config. */
public final class SscCommonConfig {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.ConfigValue<List<? extends Integer>> CURSED_MOON_PHASES = BUILDER
            .comment("Moon phases that count as a Cursed Moon (0-7). Default Fabric values are 1 and 5.")
            .defineList("cursed_moon.phases", List.of(1, 5),
                    value -> value instanceof Integer integer && integer >= 0 && integer <= 7);

    public static final ModConfigSpec.BooleanValue ALLOW_SLEEP_IN_CURSED_MOON = BUILDER
            .comment("Allow players to sleep during a Cursed Moon night.")
            .define("cursed_moon.allow_sleep", false);

    public static final ModConfigSpec.BooleanValue ENABLE_CURSED_MOON_TRANSFORM = BUILDER
            .comment("Allow the Cursed Moon to advance a player's form and restore it at dawn.")
            .define("cursed_moon.enable_transform", true);

    public static final ModConfigSpec.BooleanValue ENABLE_MOVEMENT_DEBUG_LOGGING = BUILDER
            .comment("Log detailed player movement, swimming, and jump diagnostics on this side.")
            .define("debug.movement_logging", false);

    public static final ModConfigSpec.BooleanValue WITCH_POTION_FOR_PRE_BOOK = BUILDER
            .comment("Allow witches to throw the familiar fox transformative potion at players who have not enabled the codex yet.")
            .define("transformative_effects.witch_potion_for_pre_book", false);

    public static final ModConfigSpec.BooleanValue STATUS_POTION_WITH_CURSE = BUILDER
            .comment("Allow transformative effects to be applied to players who have not enabled the codex yet.")
            .define("transformative_effects.status_potion_with_curse", false);

    public static final ModConfigSpec.DoubleValue TRANSFORMATIVE_BAT_SPAWN_CHANCE = spawnChance("transformative_bat_spawn_chance");
    public static final ModConfigSpec.DoubleValue TRANSFORMATIVE_AXOLOTL_SPAWN_CHANCE = spawnChance("transformative_axolotl_spawn_chance");
    public static final ModConfigSpec.DoubleValue TRANSFORMATIVE_OCELOT_SPAWN_CHANCE = spawnChance("transformative_ocelot_spawn_chance");
    public static final ModConfigSpec.DoubleValue TRANSFORMATIVE_WOLF_SPAWN_CHANCE = spawnChance("transformative_wolf_spawn_chance");
    public static final ModConfigSpec.DoubleValue TRANSFORMATIVE_SPIDER_SPAWN_CHANCE = spawnChance("transformative_spider_spawn_chance");

    public static final ModConfigSpec.BooleanValue IMMEDIATE_TRANSFORM = BUILDER
            .comment("Skip transformation animation and apply form changes immediately.")
            .define("transform.immediately", false);
    public static final ModConfigSpec.BooleanValue SHIFT_CRAWL = BUILDER
            .comment("Use crawling instead of crouching when holding sneak for forms with a crawling power (built-in: axolotl stages 2 and 3).")
            .define("gameplay.shift_crawl", true);
    public static final ModConfigSpec.BooleanValue FOOD_HABIT = BUILDER.define("gameplay.food_habit", true);
    public static final ModConfigSpec.BooleanValue FULL_STACK_UPGRADE = BUILDER.define("gameplay.full_stack_upgrade", true);
    public static final ModConfigSpec.BooleanValue ENABLE_INITIAL_FORM = BUILDER.define("initial_form.enabled", false);
    public static final ModConfigSpec.ConfigValue<List<? extends String>> INITIAL_FORMS = BUILDER
            .comment("Weighted forms as namespace:id:weight; omitted weight defaults to 1.")
            .defineList("initial_form.forms", List.of("shape-shifter-curse:original_before_enable:1"), value -> value instanceof String);

    public static final ModConfigSpec SPEC = BUILDER.build();

    private SscCommonConfig() {
    }

    private static ModConfigSpec.DoubleValue spawnChance(String key) {
        return BUILDER.comment("Probability of a transformative mob spawning (0 disables it; 1 guarantees it).")
                .defineInRange("transformative_mobs." + key, 0.5, 0.0, 1.0);
    }

    public static int[] cursedMoonPhases() {
        return CURSED_MOON_PHASES.get().stream().mapToInt(Number::intValue).toArray();
    }
}
