package github.com.gengyoubo.sscnf.api.registry;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import github.com.gengyoubo.sscnf.form.FormManager;
import github.com.gengyoubo.sscnf.form.FormRegistry;
import github.com.gengyoubo.sscnf.block.entity.FormAttunerBlockEntity;

import java.util.Map;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stable Java registration API for SSC extensions.
 *
 * <p>Register from the add-on mod constructor (before common setup), just like Forge registry
 * entries. IDs are global and duplicate registrations throw immediately. The class intentionally
 * has no Forge-only registration event, so the same API shape can be retained by the future
 * Fabric implementation.</p>
 *
 * <p>Registration is deliberately explicit: SSC does not scan static fields, subclasses, or
 * annotations. Prefer {@link #registrar(String)} and declare handles there, then call its
 * {@link SscRegistrar#init()} once from the owning mod entry point. This is intentionally similar
 * to Forge's DeferredRegister: it gives a form one stable registry object and avoids ad-hoc
 * construction during class loading.</p>
 *
 * <pre>{@code
 * SscJavaRegistries.registerCondition(id("is_raining"),
 *     (player, target, json) -> player.level().isRaining());
 * SscJavaRegistries.registerAction(id("jump"),
 *     (player, target, json) -> target.push(0.0, 0.5, 0.0));
 * SscJavaRegistries.registerPower(id("aura"), player -> { ... });
 * SscJavaRegistries.attachPower(id("my_form"), id("aura"));
 * // A data-defined power type: every power JSON with "type": "my_mod:pulse" uses this behaviour.
 * SscJavaRegistries.registerPowerType(id("pulse"), new SscPowerType() { ... });
 * // Lets power JSON use "key": {"key": "key.my_mod.dash"}; register the client KeyMapping
 * // with SscClientKeys so its state reaches the server.
 * SscJavaRegistries.registerPowerKey("key.my_mod.dash");
 * }</pre>
 */
public final class SscJavaRegistries {
    private static final Map<ResourceLocation, SscCondition> CONDITIONS = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, SscAction> ACTIONS = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, SscPower> POWERS = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, SscPowerType> POWER_TYPES = new ConcurrentHashMap<>();
    private static final Set<String> POWER_KEYS = ConcurrentHashMap.newKeySet();
    private static final Map<ResourceLocation, Perk> PERKS = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, PerkTree> PERK_TREES = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, ResourceLocation> PERK_TREE_IDS = new ConcurrentHashMap<>();
    private static final Map<ResourceLocation, Set<ResourceLocation>> FORM_POWERS = new ConcurrentHashMap<>();

    private SscJavaRegistries() {
    }

    /** Creates a DeferredRegister-style staging area for one mod namespace. */
    public static SscRegistrar registrar(String namespace) {
        return new SscRegistrar(namespace);
    }

    public static void registerCondition(ResourceLocation id, SscCondition condition) {
        register(CONDITIONS, id, condition, "condition");
    }

    public static void registerAction(ResourceLocation id, SscAction action) {
        register(ACTIONS, id, action, "action");
    }

    public static void registerPower(ResourceLocation id, SscPower power) {
        register(POWERS, id, power, "power");
    }

    /**
     * Registers the behaviour of a data-defined power type. {@code type} is the value of the power
     * JSON's {@code "type"} field; it must not be one of SSC's built-in types.
     */
    public static void registerPowerType(ResourceLocation type, SscPowerType powerType) {
        register(POWER_TYPES, type, powerType, "power type");
    }

    /**
     * Allows an add-on key name in power JSON ({@code "key": {"key": "key.my_mod.dash"}}) and in
     * client key packets. SSC's own {@code key.shape-shifter-curse.*}, {@code key.jump} and
     * {@code key.sprint} need no registration. Names are limited to 96 characters.
     */
    public static void registerPowerKey(String keyName) {
        Objects.requireNonNull(keyName, "key name");
        if (keyName.isEmpty() || keyName.length() > 96) {
            throw new IllegalArgumentException("SSC power key name must be 1-96 characters: '" + keyName + "'");
        }
        if (!POWER_KEYS.add(keyName)) {
            throw new IllegalStateException("Duplicate SSC power key registration: '" + keyName + "'");
        }
    }

    public static Optional<SscPowerType> powerType(ResourceLocation type) {
        return Optional.ofNullable(POWER_TYPES.get(type));
    }

    /** True when any add-on power type is registered; lets the per-tick scan exit early. */
    public static boolean hasPowerTypes() {
        return !POWER_TYPES.isEmpty();
    }

    /** True for add-on key names registered with {@link #registerPowerKey}. */
    public static boolean isPowerKey(String keyName) {
        return keyName != null && POWER_KEYS.contains(keyName);
    }

    /** Registers one immutable Perk definition. Tree layout is declared separately through {@link #registerPerkTree}. */
    public static void registerPerk(ResourceLocation id, Perk perk) {
        register(PERKS, id, perk, "perk");
        FormAttunerBlockEntity.allocateMaxLevel(perk.requiredAttunerLevel());
    }

    /**
     * Registers one Form-group-owned perk graph. Every referenced perk must already be registered,
     * and one perk may appear in only one tree so UI and ownership queries remain unambiguous.
     */
    public static synchronized void registerPerkTree(ResourceLocation id, PerkTree tree) {
        Objects.requireNonNull(id, "perk tree id");
        Objects.requireNonNull(tree, "perk tree");
        if (PERK_TREES.containsKey(id)) {
            throw new IllegalStateException("Duplicate SSC Java perk tree registration: '" + id + "'");
        }
        for (ResourceLocation perkId : tree.perks()) {
            if (!PERKS.containsKey(perkId)) {
                throw new IllegalArgumentException("Perk tree '" + id + "' references unknown perk '" + perkId + "'");
            }
            ResourceLocation existing = PERK_TREE_IDS.get(perkId);
            if (existing != null) {
                throw new IllegalStateException("SSC perk '" + perkId + "' is already owned by perk tree '" + existing + "'");
            }
        }
        PERK_TREES.put(id, tree);
        tree.perks().forEach(perkId -> PERK_TREE_IDS.put(perkId, id));
    }

    /**
     * Registers one Java form. Omitted properties inherit only from
     * {@link SscForm#inheritanceParentId()}; stage progression is intentionally not inferred
     * from that inheritance relationship and belongs in {@link Evolution}.
     *
     * <p>{@link SscForm#powers(PowerRegistrar)} is evaluated once during this call. Register
     * dynamic behaviour as an {@link SscPower}; do not expect this declaration hook to run per
     * player or per tick.</p>
     */
    public static void registerForm(SscForm form) {
        SscForm checked = Objects.requireNonNull(form, "form");
        Set<ResourceLocation> declaredPowers = checked.declaredPowers();
        FormRegistry.registerJavaForm(checked);
        declaredPowers.forEach(powerId -> attachPowerReference(checked.id(), powerId));
    }

    /**
     * Registers the complete evolution graph owned by one form family. The referenced forms may
     * be registered before or after this call, but all must exist before SSC first resolves forms.
     */
    public static void registerEvolution(Evolution evolution) {
        FormRegistry.registerJavaEvolution(Objects.requireNonNull(evolution, "evolution"));
    }

    /**
     * @deprecated Declare all form progression, including variants, through one family-owned
     * {@link Evolution}; Stage classes must not own progression edges themselves.
     */
    @Deprecated()
    public static void registerVariant(SscForm variant) {
        SscForm checked = Objects.requireNonNull(variant, "variant");
        if (checked.variantParentId() == null) {
            throw new IllegalArgumentException("SSC variant '" + checked.id() + "' must declare variantOf(...)");
        }
        registerForm(checked);
    }

    /** Attaches an already registered Java power to a form id. The form may load later from data. */
    public static void attachPower(ResourceLocation formId, ResourceLocation powerId) {
        Objects.requireNonNull(formId, "formId");
        Objects.requireNonNull(powerId, "powerId");
        if (!POWERS.containsKey(powerId)) {
            throw new IllegalArgumentException("Cannot attach unknown SSC Java power '" + powerId + "'");
        }
        attachPowerReference(formId, powerId);
    }

    /**
     * Attaches a data-defined or Java power id to a Java form. Unlike {@link #attachPower}, this
     * method intentionally permits data-defined power ids which are loaded later by /reload.
     */
    public static void attachPowerReference(ResourceLocation formId, ResourceLocation powerId) {
        Objects.requireNonNull(formId, "formId");
        Objects.requireNonNull(powerId, "powerId");
        FORM_POWERS.computeIfAbsent(formId, ignored -> ConcurrentHashMap.newKeySet()).add(powerId);
    }

    public static Optional<SscCondition> condition(ResourceLocation id) {
        return Optional.ofNullable(CONDITIONS.get(id));
    }

    public static Optional<SscAction> action(ResourceLocation id) {
        return Optional.ofNullable(ACTIONS.get(id));
    }

    public static Optional<SscPower> power(ResourceLocation id) {
        return Optional.ofNullable(POWERS.get(id));
    }

    public static Optional<Perk> perk(ResourceLocation id) {
        return Optional.ofNullable(PERKS.get(id));
    }

    public static Optional<PerkTree> perkTree(ResourceLocation id) {
        return Optional.ofNullable(PERK_TREES.get(id));
    }

    /** Returns the sole tree which owns this perk, when registered. */
    public static Optional<PerkTree> perkTreeFor(ResourceLocation perkId) {
        ResourceLocation treeId = PERK_TREE_IDS.get(perkId);
        return treeId == null ? Optional.empty() : perkTree(treeId);
    }

    /** Immutable snapshot of every perk tree available to a Form group. */
    public static Map<ResourceLocation, PerkTree> perkTreesForGroup(ResourceLocation formGroupId) {
        if (formGroupId == null) return Map.of();
        Map<ResourceLocation, PerkTree> result = new LinkedHashMap<>();
        PERK_TREES.forEach((treeId, tree) -> {
            if (formGroupId.equals(tree.formGroupId())) result.put(treeId, tree);
        });
        return Map.copyOf(result);
    }

    public static Map<ResourceLocation, PerkTree> perkTreesForForm(ResourceLocation groupId, ResourceLocation formId) {
        Map<ResourceLocation, PerkTree> result = new LinkedHashMap<>();
        perkTreesForGroup(groupId).forEach((id, tree) -> { if (tree.matchesForm(formId)) result.put(id, tree); });
        return Map.copyOf(result);
    }

    /** Direct prerequisite ids for a perk, derived exclusively from its tree edges. */
    public static Set<ResourceLocation> requiredPerks(ResourceLocation perkId) {
        return perkTreeFor(perkId).map(tree -> tree.previous(perkId)).orElseGet(Set::of);
    }

    /** Immutable snapshot of Java powers attached to one form. */
    public static Set<ResourceLocation> powersForForm(ResourceLocation formId) {
        if (formId == null) {
            return Set.of();
        }
        Set<ResourceLocation> result = new LinkedHashSet<>();
        for (ResourceLocation inheritedForm : FormRegistry.lineage(formId)) {
            Set<ResourceLocation> powers = FORM_POWERS.get(inheritedForm);
            if (powers != null) {
                result.addAll(powers);
            }
        }
        return Set.copyOf(result);
    }

    /** True only when this Java power is attached to the player's current form. */
    public static boolean isPowerActive(Player player, ResourceLocation powerId) {
        return player != null && powerId != null
                && powersForForm(FormManager.current(player).id()).contains(powerId);
    }

    /** Runs every Java power attached to the player's active form. Called by SSC's server tick. */
    public static void tickActivePowers(Player player) {
        for (ResourceLocation powerId : powersForForm(FormManager.current(player).id())) {
            SscPower power = POWERS.get(powerId);
            if (power != null) {
                power.tick(player);
            }
        }
    }

    /** Invokes a registered entity condition, returning {@code null} when the id is not Java-registered. */
    public static Boolean testCondition(ResourceLocation id, Player actor, Entity target, JsonObject data) {
        SscCondition condition = CONDITIONS.get(id);
        return condition == null ? null : condition.test(actor, target, data);
    }

    /** Invokes a registered entity action and reports whether an implementation was found. */
    public static boolean executeAction(ResourceLocation id, Player actor, LivingEntity target, JsonObject data) {
        SscAction action = ACTIONS.get(id);
        if (action == null) {
            return false;
        }
        action.execute(actor, target, data);
        return true;
    }

    private static <T> void register(Map<ResourceLocation, T> registry, ResourceLocation id, T entry, String kind) {
        Objects.requireNonNull(id, kind + " id");
        Objects.requireNonNull(entry, kind);
        if (registry.putIfAbsent(id, entry) != null) {
            throw new IllegalStateException("Duplicate SSC Java " + kind + " registration: '" + id + "'");
        }
    }
}
